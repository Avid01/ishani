.. This work is licensed under a Creative Commons Attribution 4.0
.. International License.  http://creativecommons.org/licenses/by/4.0
.. Copyright 2017 AT&T Intellectual Property.  All rights reserved.


Adding a VMware Cloud Site to ONAP
==================================

The following guide describe how to configure ONAP to be able to instantiate
a service in a new cloud site based on VMware.

TO BE COMPLETED
