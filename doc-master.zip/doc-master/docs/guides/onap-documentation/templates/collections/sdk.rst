.. This work is licensed under a Creative Commons Attribution 4.0 International License.
.. http://creativecommons.org/licenses/by/4.0

SDK
===

.. Add or remove sections below as appropriate for the SDK

.. toctree::
   :maxdepth: 1

   ../sections/architecture.rst
   ../sections/offeredapis.rst
   ../sections/delivery.rst
   ../sections/logging.rst
   ../sections/build.rst
   ../sections/release-notes.rst
