.. This work is licensed under a Creative Commons Attribution 4.0 International License.
.. http://creativecommons.org/licenses/by/4.0
.. Copyright 2021 ONAP contributors, Nokia

Consumed APIs
=============

..
   * This section is used to reference APIs that a software component depends on
     and uses from other sources.

   * Consumed APIs should be a specific link to the offered APIs from
     another component or external source.
