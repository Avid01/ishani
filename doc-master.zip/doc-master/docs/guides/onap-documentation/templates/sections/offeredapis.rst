.. This work is licensed under a Creative Commons Attribution 4.0 International License.
.. http://creativecommons.org/licenses/by/4.0
.. Copyright 2021 ONAP contributors, Nokia

Offered APIs
============

..
   * This section is used to describe the external interfaces offered by a software component

   * This section is typically: provided for a  platform-component and sdk; and
     referenced in developer guides and api reference manuals.

   * Include links to the generated JSON, HTML, and PDF versions.
